#include<iostream>
#include<fstream>
using namespace std;

class Helper
{
public:

    static int StringLength(const char* str);

    static char* StringCopy(char* source);

    static void StringCopy(char*& dest,const char*& src);

    static void StringCopy(char*& dest, char*& src);

    static char* GetStringFromBuffer(const char* buffer);

    static int CompareString(char* str1, const char* str2);

    static char* numToCharArray(int n);

    static void StringConcatenate(char*& string1, char* string2)
    {
        int len1 = StringLength(string1) + 1;
        int len2 = StringLength(string2) + 1;
        int i;
        char* newstring = new char[len1 + len2];

        for (i = 0; string1[i] != '\0'; i++)
        {
            newstring[i] = string1[i];
        }
        int j = 0;
        for (i; i < len1 + len2; i++, j++)
        {
            newstring[i] = string2[j];
        }
        delete[] string1;
        string1 = newstring;
    }
};

class Date
{
private:
    int day;
    int month;
    int year;
public:
    static Date CurrDate;
    Date(int, int, int);
    Date()
    {
        day = 0;
        month = 0; year = 0;
    }
    void setDate(int d, int m, int y)
    {
        day = d;
        month = m;
        year = y;
    }
    void Print();
    void SetDay(int);
    void SetMonth(int);
    void SetYear(int);
    int GetDay();
    int GetMonth();
    int GetYear();
    int compare(Date);
    void readDateFromFile(ifstream& fin);
    static int DayDifference(Date D1, Date D2)
    {
        if (D1.GetYear() == D2.GetYear())
        {
            if (D1.GetMonth() == D2.GetMonth())
            {
                if (D2.GetDay() - D1.GetDay() == 0 )
                {
                    return 1;
                }
                else if (D2.GetDay() - D1.GetDay() == 1 )
                {
                    return 1;
                }
                else if (D2.GetDay() - D1.GetDay() == 2)
                {
                    return 2;
                }
                else if (D2.GetDay() - D1.GetDay() == 3)
                {
                    return 3;
                }
                else if (D2.GetDay() - D1.GetDay() == 4)
                {
                    return 4;
                }
                else if (D2.GetDay() - D1.GetDay() == 5)
                {
                    return 5;
                }
                else
                    return -1;
            }
            else
                return -1;
        }
        else
            return -1;
    }
};

Date Date::CurrDate;

void Date::readDateFromFile(ifstream& fin)
{
    int dd, mm, yyyy;
    fin >> dd >> mm >> yyyy;
    day = dd;
    month = mm;
    year = yyyy;
}

Date::Date(int dd, int mm, int yy)
{
    day = dd;
    month = mm;
    year = yy;
}

void Date::Print()
{
    cout << day << "/" << month << "/" << year;
}

void Date::SetDay(int dd)
{
    day = dd;
}

void Date::SetMonth(int mm)
{
    month = mm;
}

void Date::SetYear(int yy)
{
    year = yy;
}

int Date::GetDay()
{
    return day;
}

int Date::GetMonth()
{
    return month;
}

int Date::GetYear()
{
    return year;
}

int Date::compare(Date Date2)
{
    if (year < Date2.year)
        return -1;
    else if (year > Date2.year)
        return 1;
    else
    {
        if (month < Date2.month)
            return -1;
        else if (month > Date2.month)
            return 1;
        else
        {
            if (day < Date2.day)
                return -1;
            else if (day > Date2.day)
                return 1;
            else
                return 0;
        }
    }
}

char* Helper::numToCharArray(int n)
{
    char buffer[5];
    int rem = 0;
    int i = 4;
    while (n)
    {
        rem = n % 10;
        buffer[i] = 48 + rem;
        i--;
        n = n / 10;
    }
    char buffer2[5];
    int j, k;
    for (j = i + 1, k = 0; j < 5; j++, k++)
    {
        buffer2[k] = buffer[j];
    }
    buffer2[k] = '\0';
    return Helper::GetStringFromBuffer(buffer2);
}

int Helper::StringLength(const char* str)
{
    int stringLen = 0;
    for (int i=0 ; str[i] != '\0'; i++)
        stringLen++;

    return stringLen;
}

char* Helper::StringCopy(char* source)
{
    int l = StringLength(source);

    char* copy = new char[l + 1];
    for (int i = 0; i < l; i++)
        copy[i] = source[i];
    copy[l] = '\0';

    return copy;
}

void Helper::StringCopy(char*& dest, const char*& src) {
    char* tempDest = dest;
    int i = 0;
    for (i = 0; src[i] != '\0'; i++)
    {
        tempDest[i] = src[i];
    }
    tempDest[i] = '\0';
}

void Helper::StringCopy(char*& dest, char*& src) {
    char* tempDest = dest;
    for (char* tempSrc = src; *tempSrc != '\0'; tempSrc++, tempDest++)
    {
        *tempDest = *tempSrc;
    }
    *tempDest = '\0';
}

char* Helper::GetStringFromBuffer( const char* buffer)
{
    int strLen = StringLength(buffer);
    char* str = 0;
    if (strLen > 0)
    {
        str = new char[strLen + 1];
        StringCopy(str, buffer);
    }
    return str;
}

int Helper::CompareString(char* str1, const char* str2)
{
    int size1 = StringLength(str1);
    int size2 = strlen(str2);
    for (int i = 0; i < size1; i++)
    {
        if (str1[i] != str2[i])
        {
            return 0;
        }
    }
    if (size1 == size2)
        return 1;
    else
        return 0;
}

class Post;

class Object;

class Controller;

class Activity;

class PostContent
{
public:
    virtual void printActivity()
    {

    }

    virtual ~PostContent()
    {

    }
};

class Comment;

class Comment
{
private:
    char* CommentID;
    Object* CommentBy;
    char* text;
    static int commentcount;
public:
    Comment();

    void SetValues(char* cid, Object* const& By, const char* comtext);

    //void AddComment(Object*& By, char* comtext);

    void printComment();

    ~Comment();
};
int Comment::commentcount = 1;

class Activity:public PostContent
{
private:
    int type;
    char* text;

public:
    Activity()
    {
        type = 0; text = 0;
    }
     
    void setValues(int temp, char* temptext)
    {
        type = temp;
        text = Helper::GetStringFromBuffer(temptext);
    }

    void printActivity()
    {
        switch (type)
        {
        case 1:
            cout << " is Feeling";
            break;
        case 2:
            cout << " is Thinking About";
            break;
        case 3:
            cout << " is Making";
            break;
        case 4:
            cout << " is Celebrating";
            break;
        }
        cout << text<<" ";
    }

    ~Activity()
    {
        delete[] text;
    }
};

class Post
{
private:
    char* ID;
    Object* SharedBy;
    char* Text;
    Date SharedDate;
    Object** likedBy;
    int likedcount;
    Comment** AllComments;
    int commentcount;
    PostContent* content;
public:
    static int postcount;

    Post(const char* text, Object* const& tempptr)
    {
        commentcount = 0;
        AllComments = 0;
        Text = Helper::GetStringFromBuffer(text);
        SharedBy = tempptr;
        likedBy = 0;
        likedcount = 0;
        content = 0;
        SharedDate.setDate(Date::CurrDate.GetDay(), Date::CurrDate.GetMonth(), Date::CurrDate.GetYear());
        char* temp = new char[5];
        temp[0] = 'p';
        temp[1] = 'o';
        temp[2] = 's';
        temp[3] = 't';
        temp[4] = '\0';
        ID = new char[10];
        Helper::StringCopy(ID, temp);
        char* numinstr = Helper::numToCharArray(postcount);
        Helper::StringConcatenate(ID, numinstr);
        delete[] numinstr;
        delete[] temp;
    }

    Post();

    void ReadDataFromFile(ifstream& fin);

    void setSharedBy(Object*& temp);

    void setLikedBy(Object*& temp);

    virtual void printPost();

    void printPostMemoryView();

    char* getID();

    void viewLiked();

    void AddComment(Comment*& tempptr);

    virtual ~Post();

    void AddContent( PostContent* const&);
    
    Date getDate()
    {
        return SharedDate;
    }

    int getYear()
    {
        return SharedDate.GetYear();
    }

    void printComment()
    {
        for (int i = 0; i < commentcount; i++)
            AllComments[i]->printComment();
    }

    void printMemoryHeader();
};

class Object
{ 
private:
    char* ID;
    int postcount;
protected:
    Post** Timeline;
    
public:
    char* getID()
    {
        return ID;
    }

    void setID(const char* temp)
    {
        ID = Helper::GetStringFromBuffer(temp);
    }

    int getPostCount()
    {
        return postcount;
    }

    Object(char* temp)
    {
        ID = temp;
        Timeline = 0;
        postcount = 0;
    }

    Object()
    {
        Timeline = 0;
        postcount = 0;
        ID = 0;
    }

    void AddToTimeLine(Post* const & post)
    {
        if (Timeline == nullptr)
        {
            Timeline = new Post * [10];
        }
        Timeline[postcount++] = post;
        Post::postcount++;
    }

    void viewTimeline()
    {
        for (int i = 0; i < postcount; i++)
        {
            Timeline[i]->printPost();
        }
    }

    virtual ~Object()
    {
        delete[] ID;
        for (int i = 0; i < postcount; i++)
            delete Timeline[i];
        delete[] Timeline;
    }

    virtual void print()
    {

    }

    virtual void printname()
    {

    }

    void ViewPostsFromLastTwoDays()
    {
        for (int i = 0; i < postcount; i++)
        {
            if (Date::DayDifference(Timeline[i]->getDate(), Date::CurrDate) >= 0 && Date::DayDifference(Timeline[i]->getDate(), Date::CurrDate) <= 2)
            {
                Timeline[i]->printPost();
            }
        }
    }

    void PostComment(Post* temp, const char* text)
    {
        Comment* commtemp = new Comment;
        char ID[10] = "dummy";
        commtemp->SetValues(ID, this, text);
        temp->AddComment(commtemp);
    }
};

class Page :public Object
{
private:
    
    char* Title;
public:
    Page() : Object(0)
    {
        Title = 0;
    }

    void ReadDataFromFile(ifstream& fin);

    char* getID()
    {
        return Object::getID();
    }

    char* getTitle()
    {
        return Title;
    }

    void print()
    {
        cout << getID() << " -- " << Title << endl;
    }

    void printname()
    {
        cout << Title;
    }

    ~Page()
    {
        delete[] Title;
    }
};

class User :public Object
{
private:
    
    char* Fname;
    char* Lname;
    User** FriendList;//null or 10 pointers max
    Page** LikedPages;//null or 10 pointers max
    int friendcount;
    int pagecount;
public:
    User():Object(0)
    {
        Fname = Lname = 0;
        FriendList = 0;
        LikedPages = 0;
        friendcount = 0;
        pagecount = 0;
    }

    ~User()
    {
        delete[] Fname;
        delete[] Lname;
        delete[] FriendList;
        delete[] LikedPages;
    }

    void AddFriend(User*& frnd)
    {
        if (FriendList == nullptr)
        {
            FriendList = new User * [10];
        }
        FriendList[friendcount++] = frnd;
    }

    char* getID()
    {
        return Object::getID();
    }

    void printname()
    {
        cout << Fname << " " << Lname;
    }

    void ReadDataFromFile(ifstream& fin);

    void print()
    {
        cout << getID() << " -- " << Fname << " " << Lname << endl;
    }

    void LikePage(Page*& page)
    {
        if (LikedPages == nullptr)
        {
            LikedPages = new Page * [10];
        }
        LikedPages[pagecount++] = page;
    }

    void ViewFriendList()
    {
        cout << Fname << " " << Lname << " FriendList : \n\n";
        for (int i = 0; i < friendcount; i++)
        {
            cout << "\t";
            FriendList[i]->print();
        }
        cout << endl;
    }

    void ViewLikedPages()
    {
        cout << Fname << " " << Lname << "Liked Pages : \n\n";
        for (int i = 0; i < pagecount; i++)
        {
            cout << "\t";
            LikedPages[i]->print();
        }
        cout << endl;
    }

    void ViewMemories()
    {
        cout << "We hope you enjoy looking back and sharing your memories on Facebook, from the most recent \nto those long ago.\n\n";
        for (int i = 0; i < getPostCount(); i++)
        {
            Date postdate = Timeline[i]->getDate();
            if (postdate.GetDay() == Date::CurrDate.GetDay())
            {
                if (postdate.GetMonth() == Date::CurrDate.GetMonth())
                {
                    if(postdate.GetYear() != Date::CurrDate.GetYear())
                    {
                        cout <<"On This Day - " << Date::CurrDate.GetYear() - postdate.GetYear() << " Years ago\n\t";
                        Timeline[i]->printPost();
                    }
                }
            }
        }
    }

    void viewHomepage()
    {
        this->ViewPostsFromLastTwoDays();
        for (int i = 0; i < friendcount; i++)
        {
            FriendList[i]->ViewPostsFromLastTwoDays();
        }
        for (int i = 0; i < pagecount; i++)
        {
            LikedPages[i]->ViewPostsFromLastTwoDays();
        }
    }
};

//class Comment
//{
//private:
//    char* CommentID;
//    Object* CommentBy;
//    char* text;
//public:
//    
//};

Comment::Comment()
{
    CommentID = 0;
    CommentBy = 0;
    text = 0;
    char* temp = new char[2];
    temp[0] = 'c';
    temp[1] = '\0';
    CommentID = new char[4];
    Helper::StringCopy(CommentID, temp);
    char* numinstr = Helper::numToCharArray(commentcount);
    Helper::StringConcatenate(CommentID, numinstr);
    delete[] numinstr;
    delete[] temp;
    commentcount++;
}

void Comment::SetValues(char* cid, Object* const& By, const char* comtext)
{
    if (CommentID)
        delete[] CommentID;
    CommentID = Helper::GetStringFromBuffer(cid);
    CommentBy = By;
    text = Helper::GetStringFromBuffer(comtext);
}

void Comment::printComment()
{
    CommentBy->printname();
    cout << " : \"" << text << "\"\n\t\t";
}

Comment::~Comment()
{
    delete[] CommentID;
    delete[] text;
}

void User::ReadDataFromFile(ifstream& fin)
{
    char buffer[20];
    fin >> buffer;
    setID(buffer);
    //ID = Helper::GetStringFromBuffer(buffer);
    fin>>buffer;
    Fname= Helper::GetStringFromBuffer(buffer);
    fin >> buffer;
    Lname= Helper::GetStringFromBuffer(buffer);
    
}

void Page::ReadDataFromFile(ifstream& fin)
{
    char buffer[50];
    fin >> buffer;
    setID(buffer);
    //ID = Helper::GetStringFromBuffer(buffer);
    fin.ignore();
    fin.getline(buffer, 49, '\n');
    Title = Helper::GetStringFromBuffer(buffer);

}

int Post::postcount = 1;

void Post::ReadDataFromFile(ifstream& fin)
{
    char ignorebuffer[1000];
    fin>>ignorebuffer;
    char buffer[100];
    fin >> buffer;
    delete[] ID;
    ID = Helper::GetStringFromBuffer(buffer);
    SharedDate.readDateFromFile(fin);
    fin.ignore();
    fin.getline(buffer, 99, '\n');
    Text = Helper::GetStringFromBuffer(buffer);
}

void Post:: AddComment(Comment*& tempptr)
{
    if (AllComments == nullptr)
    {
        AllComments = new Comment * [10];
    }
    if (commentcount < 10)
        AllComments[commentcount++] = tempptr;
}

void Post:: printMemoryHeader()
{
    cout << "~~~~ "; SharedBy->printname();
    cout << " Shared A memory ~~~~";
    cout << "(";
    if (SharedDate.compare(Date::CurrDate))
        SharedDate.Print();
    else
        cout << "1hr";
    cout << ")\n";
    cout << "\t\"" << Text << "\"\n\t";
}

Post::Post()
{
    commentcount = 0;
    AllComments = 0;
    Text = 0;
    SharedBy = 0;
    likedBy = 0;
    likedcount = 0;
    content = 0;
    SharedDate.setDate(Date::CurrDate.GetDay(), Date::CurrDate.GetMonth(), Date::CurrDate.GetYear());
    char* temp = new char[5];
    temp[0] = 'p';
    temp[1] = 'o';
    temp[2] = 's';
    temp[3] = 't';
    temp[4] = '\0';
    ID = new char[10];
    Helper::StringCopy(ID,temp);
    char* numinstr = Helper::numToCharArray(postcount);
    Helper::StringConcatenate(ID, numinstr);
    delete[] numinstr;
    delete[] temp;
}

void Post:: setSharedBy(Object*& temp)
{
    SharedBy = temp;
}

void Post::setLikedBy(Object*& temp)
{
    if (likedBy == nullptr)
        likedBy = new Object * [10];
    likedBy[likedcount++] = temp;
}

void Post::printPost()
{
    cout << "-- "; SharedBy->printname(); 
    if (content != nullptr)
        content->printActivity();
    cout << "("; 
    if (Date::DayDifference(this->getDate(), Date::CurrDate) == -1)
        SharedDate.Print();
    else if(Date::CurrDate.GetDay()-SharedDate.GetDay()==0)
        cout << "1hr";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 1)
        cout << "1d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 2)
        cout << "2d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 3)
        cout << "3d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 4)
        cout << "4d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 5)
        cout << "5d";
    cout << ")\n";
    cout << "\t\"" << Text << "\"\n\t\t";
    printComment();
    cout << "\n\n\n";
}

void Post::printPostMemoryView()
{
    cout << "-- "; SharedBy->printname();
    if (content != nullptr)
        content->printActivity();
    cout << "(";
    if (Date::DayDifference(this->getDate(), Date::CurrDate) == -1)
        SharedDate.Print();
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 0)
        cout << "1hr";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 1)
        cout << "1d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 2)
        cout << "2d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 3)
        cout << "3d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 4)
        cout << "4d";
    else if (Date::CurrDate.GetDay() - SharedDate.GetDay() == 5)
        cout << "5d";
    cout << ")\n";
    cout << "\t\"" << Text << "\"\n\t\t\n\n\n";
}

char* Post::getID()
{
    return ID;
}

void Post::viewLiked()
{
    cout << "Post Liked By : \n";
    for (int i = 0; i < likedcount; i++)
    {
        /*Object* Parent = likedBy[i];                         //with Dynamic Cast
        if (User* ptr = dynamic_cast<User*>(Parent))
        {
            ptr->print();cout << endl;
        }
        if (Page* ptr = dynamic_cast<Page*>(Parent))
        {
            ptr->print(); cout << endl;
        }*/

        likedBy[i]->print();
    }
}

Post::~Post()
{
    delete[] ID;
    delete[] Text;
    delete[] likedBy;
    for (int i = 0; i < commentcount; i++)
    {
        delete AllComments[i];
    }
    delete[] AllComments;
    delete content;
}

void Post::AddContent( PostContent* const & temp)
{
    content = temp;
}

class Memories:public Post
{
private:
    Post* OriginalPost;
public:

    Memories(const char* text,Post* postptr,User* currUser) : Post(text,currUser)
    {
        OriginalPost = postptr;
    }

    void printPost()
    {
        printMemoryHeader();
        cout << "~~~ " << Date::CurrDate.GetYear() - OriginalPost->getYear() << " Years Ago ~~~\n";
        cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
        OriginalPost->printPostMemoryView();
        cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
        printComment();
        cout << "\n\n\n";
    }

    ~Memories()
    {

    }

};

class Controller
{
private:
    User** AllUsers;
    Page** AllPages;
    Post** AllPosts;
    int totalusers;
    int totalpages;
    int totalposts;
    Controller()
    {
        AllUsers = 0;
        AllPages = 0;
        AllPosts = 0;
        totalpages = totalusers = totalposts = 0;;
    }
public:
    static Controller* instance;

    static Controller* getInstance()
    {
        if (instance == nullptr)
        {
            instance = new Controller;
        }
        return instance;
    }

    static void destruct()
    {
        delete instance;
    }

    ~Controller()
    {
        for (int i = 0; i < totalusers; i++)
        {
            delete AllUsers[i];
        }
        delete[] AllUsers;
        for (int i = 0; i < totalpages; i++)
        {
            delete AllPages[i];
        }
        delete[] AllPages;
       /* for (int i = 0; i < totalposts; i++)
        {
            delete AllPosts[i];
        }*/
        delete[] AllPosts;
    }

    User* SearchUserByID(char* id)
    {
        for (int i = 0; i < totalusers; i++)
        {
            char* temp = AllUsers[i]->getID();
            if (Helper::CompareString(temp, id))
                return AllUsers[i];
        }
        return 0;
    }

    Page* SearchPageByID(char* id)
    {
        for (int i = 0; i < totalpages; i++)
        {
            char* temp = AllPages[i]->getID();
            if (Helper::CompareString(temp, id))
                return AllPages[i];
        }
        return 0;
    }

    Object* SearchObjectByID(char* id)
    {
        Object* ptrtoObj=nullptr;
        if (id[0] == 'u')
        {
            ptrtoObj = SearchUserByID(id);
        }
        else
            ptrtoObj = SearchPageByID(id);
        return ptrtoObj;
    }

    Post* SearchPostByID(const char* id)
    {
        for (int i = 0; i < totalposts; i++)
        {
            char* temp = AllPosts[i]->getID();
            if (Helper::CompareString(temp, id))
                return AllPosts[i];
        }
        return 0;
    }

    void LoadAllUsers(const char* usertxt)
    {
        
        ifstream fin;
        fin.open(usertxt);
        if(fin.is_open())
        {
            int total;
            char buffer[200];
            fin >> total;
            totalusers = total;
            AllUsers = new User * [total];
            fin.ignore();
            fin.getline(buffer,199);
            fin.getline(buffer, 199);
            for (int i = 0; i < total; i++)
            {
                AllUsers[i] = new User;
                AllUsers[i]->ReadDataFromFile(fin);
            }
        }
        else
        {
            cout << "File Not Found!!!";
            exit(1);
        }
        fin.close();
    }

    void LoadAllPages(const char* pagestxt)
    {
        ifstream fin;
        fin.open(pagestxt);
        if (fin.is_open())
        {
            int total;
            char buffer[200];
            fin >> total;
            totalpages = total;
            AllPages = new Page * [total];
            fin.ignore();
            fin.getline(buffer, 199);
            fin.getline(buffer, 199);
            for (int i = 0; i < total; i++)
            {
                AllPages[i] = new Page;
                AllPages[i]->ReadDataFromFile(fin);
            }
        }
        else
        {
            cout << "File Not Found!!!";
            exit(1);
        }
        fin.close();
    }

    void LoadAllPosts(const char* poststxt)
    {
        ifstream fin;
        fin.open(poststxt);
        if (fin.is_open())
        {
            int total;
            char buffer[200];
            fin >> total;
            totalposts = total;
            AllPosts = new Post * [total];
            fin.ignore();

            for (int i = 0; i < total; i++)
            {
                AllPosts[i] = new Post;
                AllPosts[i]->ReadDataFromFile(fin);
                char buffer[5];
                fin >> buffer;
                Object* ptr = SearchObjectByID(buffer);
                AllPosts[i]->setSharedBy(ptr);
                ptr->AddToTimeLine(AllPosts[i]);
                fin >> buffer;
                while (!Helper::CompareString(buffer, "-1"))
                {
                    Object* liked = SearchObjectByID(buffer);
                    AllPosts[i]->setLikedBy(liked);
                    fin >> buffer;
                }
            }
        }
        else
        {
            cout << "File Not Found!!!";
            exit(1);
        }
        fin.close();
    }

    void AddToAllPosts(Post* const & temp)
    {
        Post** tempArray = AllPosts;
        AllPosts = new Post * [totalposts + 1];
        int i = 0;
        for (i = 0; i < totalposts; i++)
        {
            AllPosts[i] = tempArray[i];
        }
        AllPosts[i] = temp;
        delete[] tempArray;
        totalposts++;
    }

    void LoadAllComments(const char* CommentTxt)
    {
        ifstream fin;
        fin.open(CommentTxt);
        if (fin.is_open())
        {
            int TotalComments;
            fin >> TotalComments;
            for (int i = 0; i < TotalComments; i++)
            {
                char cid[10];
                char pid[10];
                char commentby[10];
                char text[100];
                fin >> cid;
                fin.ignore();
                fin >> pid;
                fin.ignore();
                fin >> commentby;
                fin.ignore();
                fin.getline(text, 99, '\n');
                Comment* ptr = new Comment;
                Object* CommentBy = SearchObjectByID(commentby);
                Post* postptr = SearchPostByID(pid);
                postptr->AddComment(ptr);
                ptr->SetValues(cid, CommentBy, text);
            }
        }
        else
        {
            cout << "File Not Found!!!";
            exit(1);
        }
        fin.close();
    }

    void LoadAllActivities(const char* ActivitiesTxt)
    {
        ifstream fin;
        fin.open(ActivitiesTxt);
        if (fin.is_open())
        {
            int totalActivites;
            fin >> totalActivites;
            for (int i = 0; i < totalActivites; i++)
            {
                Activity* ptr = new Activity;
                char pid[10];
                int type;
                char text[50];
                fin >> pid;
                Post* postptr = SearchPostByID(pid);
                fin >> type;
                fin.getline(text, 49, '\n');
                postptr->AddContent(ptr);
                ptr->setValues(type, text);
            }
        }
        else
        {
            cout << "File Not Found!!!";
            exit(1);
        }
        fin.close();
    }

    void LinkUsersAndPages(const char* filetxt)
    {
        ifstream fin;
        fin.open(filetxt);
        if (fin.is_open())
        {
            char user[5];
            char ignore[200];
            fin.getline(ignore, 199);
            fin.getline(ignore, 199);
            fin >> user;
            User* temp = 0;
            while (!Helper::CompareString(user, "-1"))
            {
                temp = SearchUserByID(user);
                char frnd[5], page[5];
                fin >> frnd;
                while (!Helper::CompareString(frnd, "-1"))
                {
                    User* frndtemp = SearchUserByID(frnd);
                    temp->AddFriend(frndtemp);
                    fin >> frnd;
                }
                fin >> page;
                while (!Helper::CompareString(page, "-1"))
                {
                    Page* pagetemp = SearchPageByID(page);
                    temp->LikePage(pagetemp);
                    fin >> page;
                }
                temp = 0;
                fin >> user;
            }
        }
        else
        { 
            cout << "File not Found!!!";
            exit(1);
        }
        fin.close();

    }

    void viewLikedList(const char* post)
    {
        Post* postptr = SearchPostByID(post);
        postptr->viewLiked();
    }

    void LikePost(const char* id,Object* &temp)
    {
        Post* postptr = SearchPostByID("post5");
        postptr->setLikedBy(temp);
    }

    void LoadData()
    {
        LoadAllUsers("Users.txt");
        LoadAllPages("Pages.txt");
        LoadAllPosts("Posts.txt");
        LoadAllComments("Comments.txt");
        LoadAllActivities("Activities.txt");
        LinkUsersAndPages("UsersFriendsAndLikedPages.txt");
    }

    void Run()
    {
        cout << "Command:\t Set Current System Date(17/04/2024) " << "\n";
        Date::CurrDate.setDate(17, 4, 2024);
        cout << "Current System date Set To :\t";
        Date::CurrDate.Print();
        cout << "\n--------------------------------------------------------------------------\n\n";
        User* temp;
        char setUser[5] = "u7";
        temp = SearchUserByID(setUser);
        if(temp)
        {

            cout << "Command:\t Set Current User " << " \" " << setUser << "\" \n";
            temp->printname();
            cout << " set as Current User\n";
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t View Friend List \n ";
            cout << "\n--------------------------------------------------------------------------\n\n";
            temp->ViewFriendList();
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t View Liked Pages \n ";
            cout << "\n--------------------------------------------------------------------------\n\n";
            temp->ViewLikedPages();
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t View TimeLine\n";
            cout << "\n--------------------------------------------------------------------------\n\n";
            temp->printname();
            cout << " -- Timeline\n\n";
            temp->viewTimeline();
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t View LikedList(post5)\n\n";
            viewLikedList("post5");
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t LikePost(post5)\n\n";
            Object* Objtemp = temp;
            Post* postptr = SearchPostByID("post5");
            if (!postptr)
            {
                cout << "Post Not Found!!!";
                exit(1);

            }
            postptr->setLikedBy(Objtemp);
            cout << "Command:\t View LikedList(post5)\n\n";
            viewLikedList("post5");
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t ViewPage(p1)\n\n";
            char pageID[4] = "p1";
            Page* pagetemp = SearchPageByID(pageID);
            char* pageName = pagetemp->getTitle();
            cout << pageName << "\n\n";
            pagetemp->viewTimeline();
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t View Home\n\n";
            cout << "\n--------------------------------------------------------------------------\n\n";
            temp->printname();
            cout << " -- Home Page\n\n";
            temp->viewHomepage();
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t PostComment(post8,Thanks For The Wishes)\n";
            Post* PostToBeCommentedOn = SearchPostByID("post8");
            temp->PostComment(PostToBeCommentedOn, "Thanks For The Wishes");
            cout << "command: View Post\n\n";
            PostToBeCommentedOn->printPost();
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t View Memories\n\n";
            cout << "\n--------------------------------------------------------------------------\n\n";
            temp->printname();
            cout << " -- Memories\n\n";
            temp->ViewMemories();
            Post* postptr2 = SearchPostByID("post10");
            Memories* ptr = new Memories("Never thought I will be specialist in this field...", postptr2, temp);
            temp->AddToTimeLine(ptr);
            AddToAllPosts(ptr);
            temp->PostComment(ptr, "Wowwww.So Happy For You");
            cout << "\n--------------------------------------------------------------------------\n\n";
            cout << "Command:\t ShareMemory(post10, \"Never thought I will be specialist in this field...\")\n";
            cout << "Command:\t View TimeLine\n";
            cout << "\n--------------------------------------------------------------------------\n\n";
            temp->printname();
            cout << " -- Timeline\n\n";
            temp->viewTimeline();
            cout << "\n--------------------------------------------------------------------------\n\n";
        }
        else
        {
            cout << "User Not Found";
            exit(1);
        }
    }

};

Controller* Controller::instance=0;

int main()
{
    {
        Controller* mainApp= Controller::getInstance();
        mainApp->LoadData();
        mainApp->Run();
        Controller::destruct();
    }
    _CrtDumpMemoryLeaks();
    return 0;
}
